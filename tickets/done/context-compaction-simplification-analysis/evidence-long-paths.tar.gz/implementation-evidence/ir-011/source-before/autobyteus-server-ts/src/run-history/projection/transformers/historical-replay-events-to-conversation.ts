import type { EventMonitorReplayEvent } from "../historical-replay-event-types.js";
import type { RunProjectionConversationEntry } from "../run-projection-types.js";

export const buildRunProjectionConversation = (
  events: EventMonitorReplayEvent[],
): RunProjectionConversationEntry[] =>
  events.flatMap<RunProjectionConversationEntry>((event) => {
    if (event.kind === "message" && event.role === "user" && event.senderId) {
      // RD-004: an agent-to-agent delivery replays as "From <Sender>:", not as a user bubble.
      return [{
        kind: "inter_agent_message",
        role: "user",
        senderAgentRunId: event.senderId,
        senderAddress: null,
        ...(event.fileAttachments?.length ? { fileAttachments: event.fileAttachments } : {}),
        content: event.content,
        media: event.media,
        ts: event.ts,
      }];
    }

    if (event.kind === "message") {
      return [{
        kind: "message",
        role: event.role,
        ...(event.role === "user" && event.fileAttachments?.length ? { fileAttachments: event.fileAttachments } : {}),
        content: event.content,
        media: event.media,
        ts: event.ts,
      }];
    }

    if (event.kind === "reasoning") {
      return [{
        kind: "reasoning",
        role: null,
        content: event.content,
        media: event.media,
        ts: event.ts,
      }];
    }

    if (event.kind === "compaction") {
      return [];
    }

    if (event.kind === "system_task_notification") {
      return [{
        kind: "system_task_notification",
        role: null,
        senderId: event.senderId,
        content: event.content,
        ts: event.ts,
      }];
    }

    return [{
      kind:
        event.status === "parsed" || event.status === "parsing"
          ? "tool_call_pending"
          : "tool_call",
      invocationId: event.invocationId,
      role: null,
      content: event.content,
      toolName: event.toolName,
      toolArgs: event.toolArgs,
      toolResult: event.toolResult,
      toolError: event.toolError,
      media: event.media,
      ts: event.ts,
    }];
  });
