import type { WorkspaceManager } from "../../../../workspaces/workspace-manager.js";
import { getWorkspaceManager } from "../../../../workspaces/workspace-manager.js";
import {
  type ClaudeSessionEvent,
} from "../claude-runtime-shared.js";
import { normalizeSessionMessages } from "../claude-runtime-message-normalizers.js";
import { ClaudeSessionMessageCache } from "./claude-session-message-cache.js";
import { ClaudeSessionToolUseCoordinator } from "./claude-session-tool-use-coordinator.js";
import { ClaudeSession } from "./claude-session.js";
import { ClaudeSessionCleanup } from "./claude-session-cleanup.js";
import { ClaudeSessionEventName } from "../events/claude-session-event-name.js";
import { ClaudeWorkspaceResolver } from "../claude-workspace-resolver.js";
import {
  ClaudeSdkClient,
  getClaudeSdkClient,
} from "../../../../runtime-management/claude/client/claude-sdk-client.js";
import type { ClaudeRunContext } from "../backend/claude-agent-run-context.js";
import { ClaudeProviderSessionLifecycle } from "./claude-provider-session-lifecycle.js";
import type {
  AgentToolMcpRunSessionAuthority,
} from "../../../../agent-tools/mcp/agent-tool-mcp-session-authority.js";
import {
  getClaudeWorkspaceSkillMaterializer,
} from "../claude-workspace-skill-materializer.js";
import type {
  WorkspaceSkillMaterializer,
} from "../../shared/workspace-skill-materializer.js";
export type { ClaudeSessionEvent } from "../claude-runtime-shared.js";
export { ClaudeSession } from "./claude-session.js";

export class ClaudeSessionManager {
  private workspaceManager: WorkspaceManager;
  private readonly released = new WeakSet<ClaudeSession>();
  private readonly releaseAttempts = new WeakMap<ClaudeSession, Promise<void>>();
  private readonly sessions = new Map<string, ClaudeSession>();
  private readonly sessionMessageCache = new ClaudeSessionMessageCache();
  private readonly sdkClient: ClaudeSdkClient;
  private readonly agentToolMcpRunSessions: AgentToolMcpRunSessionAuthority;
  private readonly toolingCoordinator = new ClaudeSessionToolUseCoordinator(
    new Map(),
    new Map(),
    (runContext, event) => this.requireRunSession(runContext.runId).emitRuntimeEvent(event),
  );
  private readonly sessionCleanup: ClaudeSessionCleanup;

  constructor(
    agentToolMcpRunSessions: AgentToolMcpRunSessionAuthority,
    workspaceManager: WorkspaceManager = getWorkspaceManager(),
    sdkClient: ClaudeSdkClient = getClaudeSdkClient(),
    workspaceSkillMaterializer: WorkspaceSkillMaterializer =
      getClaudeWorkspaceSkillMaterializer(),
  ) {
    if (!agentToolMcpRunSessions) {
      throw new Error("Claude Agent Tools MCP run-session activator is required.");
    }
    this.workspaceManager = workspaceManager;
    this.sdkClient = sdkClient;
    this.agentToolMcpRunSessions = agentToolMcpRunSessions;
    this.sessionCleanup = new ClaudeSessionCleanup(workspaceSkillMaterializer);
  }

  async createRunSession(
    runContext: ClaudeRunContext,
    ownSession: (session: ClaudeSession) => void,
  ): Promise<ClaudeSession> {
    await this.closeRunSession(runContext.runId);
    runContext.runtimeContext.hasCompletedTurn = false;
    runContext.runtimeContext.activeTurnId = null;
    const providerSessionLifecycle = ClaudeProviderSessionLifecycle.reserveNew();
    let session!: ClaudeSession;
    session = new ClaudeSession({
      runContext,
      providerSessionLifecycle,
      dependencies: this.buildSessionDependencies(runContext.runId, () => session),
    });
    this.sessions.set(runContext.runId, session);
    ownSession(session);
    this.sessionMessageCache.ensureSession(session.sessionId);
    return session;
  }

  async restoreRunSession(
    runContext: ClaudeRunContext,
    sessionId: string,
    ownSession: (session: ClaudeSession) => void,
  ): Promise<ClaudeSession> {
    await this.closeRunSession(runContext.runId);
    const providerSessionLifecycle = ClaudeProviderSessionLifecycle.restore(sessionId, runContext.runId);
    runContext.runtimeContext.hasCompletedTurn = false;
    runContext.runtimeContext.activeTurnId = null;
    let session!: ClaudeSession;
    session = new ClaudeSession({
      runContext,
      providerSessionLifecycle,
      dependencies: this.buildSessionDependencies(runContext.runId, () => session),
    });
    this.sessions.set(runContext.runId, session);
    ownSession(session);
    this.sessionMessageCache.ensureSession(providerSessionLifecycle.sessionId);
    return session;
  }

  hasRunSession(runId: string): boolean {
    return this.sessions.has(runId);
  }

  async terminateRun(runId: string): Promise<void> {
    const state = this.sessions.get(runId);
    if (!state) {
      return;
    }
    await state.closeProcess("Tool approval cancelled because run was closed.");
    state.emitRuntimeEvent({
      method: ClaudeSessionEventName.SESSION_TERMINATED,
      params: {
        runId,
      },
    });
    await this.closeRunSession(runId);
  }

  async closeRunSession(runId: string): Promise<void> {
    const state = this.sessions.get(runId);
    if (!state) {
      return;
    }
    await this.releaseExactSession(state);
  }

  releaseExactSession(session: ClaudeSession): Promise<void> {
    if (this.released.has(session)) return Promise.resolve();
    if (this.sessions.get(session.runId) !== session) return Promise.reject(new Error("Claude exact session authority mismatch."));
    const existing = this.releaseAttempts.get(session);
    if (existing) return existing;
    const attempt = this.sessionCleanup.cleanupSessionResources({ session }).then(() => {
      if (this.sessions.get(session.runId) === session) this.sessions.delete(session.runId);
      this.released.add(session);
    });
    this.releaseAttempts.set(session, attempt);
    void attempt.finally(() => { if (this.releaseAttempts.get(session) === attempt) this.releaseAttempts.delete(session); }).catch(() => undefined);
    return attempt;
  }

  async getSessionMessages(
    sessionId: string,
  ): Promise<Array<Record<string, unknown>>> {
    const normalizedSessionId = sessionId.trim();
    if (!normalizedSessionId) {
      return [];
    }
    const cachedMessages = this.sessionMessageCache.getCachedMessages(normalizedSessionId);
    const raw = await this.sdkClient.getSessionMessages(normalizedSessionId);
    const normalized = normalizeSessionMessages(raw);
    if (normalized.length > 0) {
      return this.sessionMessageCache.getMergedMessages(normalizedSessionId, normalized);
    }

    return cachedMessages;
  }

  async listModels() {
    return this.sdkClient.listModels();
  }

  async resolveWorkingDirectory(workspaceId?: string | null): Promise<string> {
    return new ClaudeWorkspaceResolver(this.workspaceManager).resolveWorkingDirectory(workspaceId);
  }

  requireRunSession(runId: string): ClaudeSession {
    const session = this.sessions.get(runId);
    if (!session) {
      throw new Error(`Claude runtime session '${runId}' is not available.`);
    }
    return session;
  }

  private buildSessionDependencies(runId: string, exact: () => ClaudeSession) {
    return {
      sessionMessageCache: this.sessionMessageCache,
      sdkClient: this.sdkClient,
      toolingCoordinator: this.toolingCoordinator,
      agentToolMcpRunSessions: this.agentToolMcpRunSessions,
      isRunSessionActive: () => this.sessions.get(runId) === exact(),
      terminateRunSession: () => this.releaseExactSession(exact()),
    };
  }
}
