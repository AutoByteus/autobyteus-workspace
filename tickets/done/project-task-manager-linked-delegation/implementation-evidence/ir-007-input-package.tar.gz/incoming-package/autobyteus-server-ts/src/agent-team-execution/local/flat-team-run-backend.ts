import type { AgentInputUserMessage } from "autobyteus-ts/agent/message/agent-input-user-message.js";
import type { AgentRunInputOptions } from "../../agent-execution/input/agent-run-input-contract.js";
import { TeamBackendKind } from "../domain/team-backend-kind.js";
import type { PrepareTaskAgentInput, RestoreTaskAgentInput } from "../domain/task-agent-execution.js";
import type { PrepareTaskTeamInput, RestoreTaskTeamInput } from "../domain/task-team-execution.js";
import type { TaskExecutionReference } from "../../agent-collaboration/execution/task/task-execution-reference.js";
import type { TeamMemberExecutionCommand } from "../domain/team-member-execution-command.js";
import type { TeamRunBackend } from "../backends/team-run-backend.js";
import type { FlatTeamExecutionManager } from "./flat-team-execution-manager.js";
import type { FlatTeamExecutionContextEnvelope } from "./flat-team-execution-context.js";

export class FlatTeamRunBackend implements TeamRunBackend {
  constructor(
    private readonly context: FlatTeamExecutionContextEnvelope,
    private readonly manager: FlatTeamExecutionManager,
  ) {}

  getTeamRunContext(): FlatTeamExecutionContextEnvelope { return this.context; }
  get teamRunId(): string { return this.context.teamRunId; }
  get teamBackendKind() { return TeamBackendKind.MIXED; }
  getRuntimeContext() { return this.context.runtimeContext; }
  isActive(): boolean { return this.manager.isActive(); }
  isTerminated(): boolean { return this.manager.isTerminated(); }
  getInputStateSnapshots() { return this.manager.getInputStateSnapshots(); }
  getLeafAgentStatusSnapshots() { return this.manager.getLeafAgentStatusSnapshots(); }
  hasOpenExecutionWork(): boolean { return this.manager.hasOpenExecutionWork(); }
  reserveDirectAgentInput(agentRunId: string, message: AgentInputUserMessage, options: AgentRunInputOptions = {}) {
    return this.manager.reserveDirectAgentInput(agentRunId, message, options);
  }
  deliverToDirectAgent(agentRunId: string, message: AgentInputUserMessage) {
    return this.manager.deliverToDirectAgent(agentRunId, message);
  }
  executeDirectAgentCommand(agentRunId: string, command: TeamMemberExecutionCommand) {
    return this.manager.executeDirectAgentCommand(agentRunId, command);
  }
  beginTaskAgent(input: PrepareTaskAgentInput) { return this.manager.beginTaskAgent(input); }
  beginTaskTeam(input: PrepareTaskTeamInput) { return this.manager.beginTaskTeam(input); }
  restoreTaskAgent(input: RestoreTaskAgentInput) { return this.manager.restoreTaskAgent(input); }
  restoreTaskTeam(input: RestoreTaskTeamInput) { return this.manager.restoreTaskTeam(input); }
  cancelDirectTaskExecution(reference: TaskExecutionReference) { this.manager.cancelDirectTaskExecution(reference); }
  releaseDirectTaskExecution(reference: TaskExecutionReference) { return this.manager.releaseDirectTaskExecution(reference); }
  hasLiveDirectTaskExecution(reference: TaskExecutionReference) { return this.manager.hasLiveDirectTaskExecution(reference); }
  tryShutDownDirectTaskExecutionIfQuiet(reference: TaskExecutionReference) {
    return this.manager.tryShutDownDirectTaskExecutionIfQuiet(reference);
  }
  cancelRuntimeActivation() { this.manager.cancelRuntimeActivation(); }
  releaseOwnedRuntime() { return this.manager.releaseOwnedRuntime(); }
  prepareTermination() { return this.manager.prepareTermination(); }
  tryPrepareTerminationIfQuiescent() { return this.manager.tryPrepareTerminationIfQuiescent(); }
  freezeForRootTermination() { return this.manager.freezeForRootTermination(); }
  terminate() { return this.manager.terminate(); }
}
