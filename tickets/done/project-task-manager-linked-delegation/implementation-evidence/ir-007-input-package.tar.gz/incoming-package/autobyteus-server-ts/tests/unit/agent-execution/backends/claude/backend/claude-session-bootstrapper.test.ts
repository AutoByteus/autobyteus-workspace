import { WORK_REQUEST_EXECUTION_LLM_INSTRUCTION } from "../../../../../../src/agent-collaboration/domain/agent-team-collaboration-llm-contract.js";
import { describe, expect, it, vi } from "vitest";
import { AgentRunConfig } from "../../../../../../src/agent-execution/domain/agent-run-config.js";
import { AgentRunContext } from "../../../../../../src/agent-execution/domain/agent-run-context.js";
import { ClaudeSessionBootstrapper } from "../../../../../../src/agent-execution/backends/claude/backend/claude-session-bootstrapper.js";
import { MemberExecutionContext } from "../../../../../../src/agent-collaboration/execution/domain/member-execution-context.js";
import { RuntimeKind } from "../../../../../../src/runtime-management/runtime-kind-enum.js";
import { Skill } from "../../../../../../src/skills/domain/models.js";
import type { ConfiguredAgentSkillBinding } from "../../../../../../src/skills/domain/configured-agent-skill-binding.js";
import { testMemberExecutionContext } from "../../../../../fixtures/current-team-run-fixtures.js";

const WORKING_DIRECTORY = "/tmp/claude-bootstrapper-workspace";

const createMemberExecutionContext = () =>
  testMemberExecutionContext({
    teamRunId: "team-run-1",
    rootTeamRunId: "team-run-1",
    teamDefinitionId: "team-def-1",
    memberAddress: "/Professor",
    coordinatorAddress: "/Professor",
    agentRunId: "run-claude-team",
    runtimeKind: RuntimeKind.CLAUDE_AGENT_SDK,
    deliverInterAgentMessage: vi.fn(async () => undefined) as any,
  });

const createRunContext = (input: {
  autoExecuteTools: boolean;
  memberExecutionContext?: MemberExecutionContext | null;
}) =>
  new AgentRunContext({
    runId: input.memberExecutionContext?.agentRunId ?? "run-claude-standalone",
    config: new AgentRunConfig({
      runtimeKind: RuntimeKind.CLAUDE_AGENT_SDK,
      agentDefinitionId: "agent-def-claude",
      llmModelIdentifier: "haiku",
      autoExecuteTools: input.autoExecuteTools,
      workspaceId: "workspace-claude",
      memberExecutionContext: input.memberExecutionContext ?? null,
    }),
    runtimeContext: null,
  });

const createBootstrapper = (bindings: ConfiguredAgentSkillBinding[] = [], skillScope: "CONFIGURED" | "ALL_INSTALLED" = "CONFIGURED") => {
  const workspaceSkillMaterializer = { materializeConfiguredWorkspaceSkills: vi.fn(async () => []) };
  const bootstrapper = new ClaudeSessionBootstrapper(
    { resolveWorkingDirectory: vi.fn(async () => WORKING_DIRECTORY) } as any,
    workspaceSkillMaterializer as any,
    {
      getAgentDefinitionById: vi.fn(async () => ({
        name: "Professor agent",
        instructions: "Teach the class.",
        description: "Professor",
        skillNames: bindings.map((binding) => binding.kind === "resolved" ? binding.skill.name : binding.name),
        toolNames: [],
      })),
    } as any,
    { resolveSkillScope: () => skillScope, resolveConfiguredSkillBindingsForAgent: vi.fn(() => bindings) } as any,
  );
  return { bootstrapper, workspaceSkillMaterializer };
};

describe("ClaudeSessionBootstrapper", () => {
  it("keeps team autoExecuteTools as AutoByteus approval state while using default provider permission mode", async () => {
    const memberExecutionContext = createMemberExecutionContext();
    const { bootstrapper } = createBootstrapper();

    const runContext = await bootstrapper.bootstrapForCreate(
      createRunContext({
        autoExecuteTools: true,
        memberExecutionContext,
      }), { assertAccepting: () => undefined, ownSkill: () => undefined, ownCodexClient: () => undefined },
    );

    expect(runContext.runtimeContext.sessionConfig).toMatchObject({
      model: "haiku",
      workingDirectory: WORKING_DIRECTORY,
      permissionMode: "default",
      autoExecuteTools: true,
    });
    expect(runContext.runtimeContext.autoExecuteTools).toBe(true);
    expect(runContext.config.memberExecutionContext).toBe(memberExecutionContext);
    expect(runContext.runtimeContext.carpenterSystemPrompt).toContain("## Agent Identity");
    expect(runContext.runtimeContext.carpenterSystemPrompt).toContain("## AgentTeam Addressing");
    expect(runContext.runtimeContext.carpenterSystemPrompt).toContain("## AgentTeam Collaboration");
    expect(runContext.runtimeContext.carpenterSystemPrompt.split(WORK_REQUEST_EXECUTION_LLM_INSTRUCTION)).toHaveLength(2);
    expect(runContext.runtimeContext.carpenterSystemPrompt).not.toContain("## Team Runtime");
    expect(runContext.runtimeContext.carpenterSystemPrompt).not.toContain("## Working Environment");
    expect(runContext.runtimeContext.carpenterSystemPrompt).not.toContain("## Bash Operating Practice");
    expect(runContext.runtimeContext.carpenterSystemPrompt).not.toContain("## File And Directory Practice");
  });

  it("maps resolved and unresolved bindings to shared reconciliation requests in order", async () => {
    const skill = new Skill({
      name: "claude-skill",
      description: "test",
      content: "# Claude skill",
      rootPath: "/tmp/claude-skill",
    });
    const { bootstrapper, workspaceSkillMaterializer } = createBootstrapper([
      { kind: "resolved", skill },
      { kind: "unresolved", name: "missing-skill" },
    ]);

    const runContext = await bootstrapper.bootstrapForCreate(createRunContext({
      autoExecuteTools: false,
    }), { assertAccepting: () => undefined, ownSkill: () => undefined, ownCodexClient: () => undefined });

    expect(workspaceSkillMaterializer.materializeConfiguredWorkspaceSkills).toHaveBeenCalledWith(expect.objectContaining({
      runId: "run-claude-standalone",
      workingDirectory: WORKING_DIRECTORY,
      requests: [
        { kind: "expose-resolved", skill },
        { kind: "reconcile-unresolved", name: "missing-skill" },
      ],
      workspaceCollisionPolicy: "fail",
    }));
    expect(runContext.runtimeContext.configuredSkills).toEqual([skill]);
  });

  it("prefers user-owned workspace entries for an ALL_INSTALLED definition (D-15 Rule 1)", async () => {
    const skill = new Skill({ name: "installed-skill", description: "d", content: "# c", rootPath: "/skills/installed-skill" });
    const { bootstrapper, workspaceSkillMaterializer } = createBootstrapper([
      { kind: "resolved", skill },
    ], "ALL_INSTALLED");

    await bootstrapper.bootstrapForCreate(createRunContext({ autoExecuteTools: false }), { assertAccepting: () => undefined, ownSkill: () => undefined, ownCodexClient: () => undefined });

    expect(workspaceSkillMaterializer.materializeConfiguredWorkspaceSkills).toHaveBeenCalledWith(
      expect.objectContaining({ workspaceCollisionPolicy: "prefer_workspace" }));
  });
});
