import{L as l,E as m,M as i}from"#entry";const g=l`
  query GetTools($origin: ToolOriginEnum, $sourceServerId: String) {
    tools(origin: $origin, sourceServerId: $sourceServerId) {
      __typename
      name
      description
      origin
      category
      argumentSchema {
        __typename
        parameters {
          __typename
          name
          paramType
          description
          required
          defaultValue
          enumValues
        }
      }
    }
  }
`,h=l`
  query GetToolsGroupedByCategory($origin: ToolOriginEnum!) {
    toolsGroupedByCategory(origin: $origin) {
      __typename
      categoryName
      tools {
        __typename
        name
        description
        origin
        category
        argumentSchema {
          __typename
          parameters {
            __typename
            name
            paramType
            description
            required
            defaultValue
            enumValues
          }
        }
      }
    }
  }
`,y=l`
  query GetMcpServers {
    mcpServers {
      __typename
      ... on StdioMcpServerConfig {
        serverId
        transportType
        enabled
        toolNamePrefix
        command
        args
        env
        cwd
      }
      ... on StreamableHttpMcpServerConfig {
        serverId
        transportType
        enabled
        toolNamePrefix
        url
        token
        headers
      }
    }
  }
`,v=l`
  query PreviewMcpServerTools($input: McpServerInput!) {
    previewMcpServerTools(input: $input) {
      __typename
      name
      description
    }
  }
`,f=l`
  mutation ConfigureMcpServer($input: McpServerInput!) {
    configureMcpServer(input: $input) {
      savedConfig {
        __typename
        ... on StdioMcpServerConfig {
          serverId
          transportType
          enabled
          toolNamePrefix
          command
          args
          env
          cwd
        }
        ... on StreamableHttpMcpServerConfig {
          serverId
          transportType
          enabled
          toolNamePrefix
          url
          token
          headers
        }
      }
    }
  }
`,S=l`
  mutation DeleteMcpServer($serverId: String!) {
    deleteMcpServer(serverId: $serverId) {
      __typename
      success
      message
    }
  }
`,w=l`
  mutation DiscoverAndRegisterMcpServerTools($serverId: String!) {
    discoverAndRegisterMcpServerTools(serverId: $serverId) {
      __typename
      success
      message
      discoveredTools {
        __typename
        name
        description
        origin
        category
        argumentSchema {
          __typename
          parameters {
            __typename
            name
            paramType
            description
            required
            defaultValue
            enumValues
          }
        }
      }
    }
  }
`,T=l`
    mutation ImportMcpServerConfigs($jsonString: String!) {
        importMcpServerConfigs(jsonString: $jsonString) {
            __typename
            success
            message
            importedCount
            failedCount
        }
    }
`,_=l`
  mutation ReloadToolSchema($name: String!) {
    reloadToolSchema(name: $name) {
      success
      message
      tool {
        __typename
        name
        description
        origin
        category
        argumentSchema {
          __typename
          parameters {
            __typename
            name
            paramType
            description
            required
            defaultValue
            enumValues
          }
        }
      }
    }
  }
`,E=m("toolManagement",{state:()=>({localTools:[],localToolsByCategory:[],mcpServers:[],toolsByServerId:{},loading:!1,error:null,previewResult:null}),getters:{getLocalTools:e=>e.localTools,getLocalToolsByCategory:e=>e.localToolsByCategory,getMcpServers:e=>e.mcpServers,getLoading:e=>e.loading,getError:e=>e.error,getPreviewResult:e=>e.previewResult,getToolsForServer:e=>r=>e.toolsByServerId[r]||[]},actions:{async fetchLocalTools(){return this.fetchLocalToolsGroupedByCategory()},async fetchLocalToolsGroupedByCategory(){this.loading=!0,this.error=null;try{const e=i(),{data:r,errors:t}=await e.query({query:h,variables:{origin:"LOCAL"},fetchPolicy:"network-only"});if(t&&t.length>0)throw new Error(t.map(s=>s.message).join(", "));const o=r?.toolsGroupedByCategory??[];this.localToolsByCategory=o,this.localTools=o.flatMap(s=>s.tools)}catch(e){throw this.error=e,console.error("Failed to fetch grouped local tools:",e),e}finally{this.loading=!1}},async fetchMcpServers(){this.loading=!0,this.error=null;try{const e=i(),{data:r,errors:t}=await e.query({query:y,fetchPolicy:"network-only"});if(t&&t.length>0)throw new Error(t.map(s=>s.message).join(", "));const o=r?.mcpServers??[];this.mcpServers=o}catch(e){throw this.error=e,console.error("Failed to fetch MCP servers:",e),e}finally{this.loading=!1}},async fetchToolsForServer(e){this.loading=!0,this.error=null;try{const r=i(),{data:t,errors:o}=await r.query({query:g,variables:{sourceServerId:e},fetchPolicy:"network-only"});if(o&&o.length>0)throw new Error(o.map(n=>n.message).join(", "));const s=t?.tools??[];this.$patch(n=>{n.toolsByServerId[e]=s})}catch(r){throw this.error=r,console.error(`Failed to fetch tools for server ${e}:`,r),r}finally{this.loading=!1}},async previewMcpServer(e){this.loading=!0,this.previewResult=null,this.error=null;try{const r=i(),{data:t,errors:o}=await r.query({query:v,variables:{input:e},fetchPolicy:"network-only"});if(o&&o.length>0){const s=o.map(n=>n.message).join(", ");throw new Error(s)}this.previewResult={tools:t?.previewMcpServerTools??[],isError:!1,message:""}}catch(r){this.error=r;const t=r?.graphQLErrors?.[0]?.message;throw this.previewResult={tools:[],isError:!0,message:t||(r instanceof Error?r.message:"An unknown error occurred.")},r}finally{this.loading=!1}},async configureMcpServer(e){this.loading=!0,this.error=null;try{const r=i(),{data:t,errors:o}=await r.mutate({mutation:f,variables:{input:e}});if(o&&o.length>0)throw new Error(o.map(s=>s.message).join(", "));if(t?.configureMcpServer)return await this.fetchMcpServers(),t.configureMcpServer;throw new Error("Failed to configure MCP server: No data returned")}catch(r){throw this.error=r,r}finally{this.loading=!1}},async deleteMcpServer(e){this.loading=!0,this.error=null;try{const r=i(),{data:t,errors:o}=await r.mutate({mutation:S,variables:{serverId:e}});if(o&&o.length>0)throw new Error(o.map(s=>s.message).join(", "));if(t?.deleteMcpServer)return t.deleteMcpServer.success&&await this.fetchMcpServers(),t.deleteMcpServer;throw new Error("Failed to delete MCP server: No data returned")}catch(r){throw this.error=r,r}finally{this.loading=!1}},async discoverAndRegisterMcpServerTools(e){this.loading=!0,this.error=null;try{const r=i(),{data:t,errors:o}=await r.mutate({mutation:w,variables:{serverId:e}});if(o&&o.length>0)throw new Error(o.map(s=>s.message).join(", "));if(t?.discoverAndRegisterMcpServerTools)return t.discoverAndRegisterMcpServerTools.success&&await this.fetchToolsForServer(e),t.discoverAndRegisterMcpServerTools;throw new Error("Failed to discover tools: No data returned")}catch(r){throw this.error=r,r}finally{this.loading=!1}},async importMcpServerConfigs(e){this.loading=!0,this.error=null;try{const r=i(),{data:t,errors:o}=await r.mutate({mutation:T,variables:{jsonString:e}});if(o&&o.length>0)throw new Error(o.map(s=>s.message).join(", "));if(t?.importMcpServerConfigs)return t.importMcpServerConfigs.imported_count>0&&await this.fetchMcpServers(),t.importMcpServerConfigs;throw new Error("Failed to import configs: No data returned")}catch(r){throw this.error=r,r}finally{this.loading=!1}},async reloadToolSchema(e){this.loading=!0,this.error=null;try{const r=i(),{data:t,errors:o}=await r.mutate({mutation:_,variables:{name:e}});if(o&&o.length>0)throw new Error(o.map(n=>n.message).join(", "));const s=t?.reloadToolSchema;if(!s)throw new Error("No response from server on schema reload.");if(s.success&&s.tool){const n=s.tool,u=this.localTools.findIndex(a=>a.name===e);if(u!==-1){const a=[...this.localTools];a[u]=n,this.localTools=a}this.localToolsByCategory=this.localToolsByCategory.map(a=>{const p=a.tools.findIndex(c=>c.name===e);if(p!==-1){const c=[...a.tools];return c[p]=n,{...a,tools:c}}return a});for(const a in this.toolsByServerId){const p=this.toolsByServerId[a],c=p.findIndex(d=>d.name===e);if(c!==-1){const d=[...p];d[c]=n,this.toolsByServerId[a]=d;break}}}return{success:s.success,message:s.message,tool:s.tool}}catch(r){throw this.error=r,console.error(`Failed to reload schema for tool ${e}:`,r),r}finally{this.loading=!1}},clearError(){this.error=null},clearPreviewResult(){this.previewResult=null}}});export{E as u};
