import{L as v,E as P,c as k,p as f,M as m}from"#entry";const x=v`
  query GetSkills {
    skills {
      name
      description
      content
      rootPath
      fileCount
      isReadonly
      isDisabled
      isVersioned
      activeVersion
    }
  }
`,R=v`
  query GetSkill($name: String!) {
    skill(name: $name) {
      name
      description
      content
      rootPath
      fileCount
      isReadonly
      isDisabled
      isVersioned
      activeVersion
    }
  }
`,O=v`
  query GetSkillFileTree($name: String!) {
    skillFileTree(name: $name)
  }
`,U=v`
  query GetSkillFileContent($skillName: String!, $path: String!) {
    skillFileContent(skillName: $skillName, path: $path)
  }
`,B=v`
  mutation CreateSkill($input: CreateSkillInput!) {
    createSkill(input: $input) {
      name
      description
      content
      rootPath
      fileCount
      isVersioned
      activeVersion
    }
  }
`,H=v`
  mutation UpdateSkill($input: UpdateSkillInput!) {
    updateSkill(input: $input) {
      name
      description
      content
      rootPath
      fileCount
      isVersioned
      activeVersion
    }
  }
`,M=v`
  mutation DeleteSkill($name: String!) {
    deleteSkill(name: $name) {
      success
      message
    }
  }
`,z=v`
  mutation UploadSkillFile($skillName: String!, $path: String!, $content: String!) {
    uploadSkillFile(skillName: $skillName, path: $path, content: $content)
  }
`,J=v`
  mutation DeleteSkillFile($skillName: String!, $path: String!) {
    deleteSkillFile(skillName: $skillName, path: $path)
  }
`,Q=v`
  mutation DisableSkill($name: String!) {
    disableSkill(name: $name) {
      name
      isDisabled
      isVersioned
      activeVersion
    }
  }
`,W=v`
  mutation EnableSkill($name: String!) {
    enableSkill(name: $name) {
      name
      isDisabled
      isVersioned
      activeVersion
    }
  }
`,X=v`
  query GetSkillVersions($skillName: String!) {
    skillVersions(skillName: $skillName) {
      tag
      commitHash
      message
      createdAt
      isActive
    }
  }
`,Y=v`
  query GetSkillVersionDiff(
    $skillName: String!
    $fromVersion: String!
    $toVersion: String!
  ) {
    skillVersionDiff(
      skillName: $skillName
      fromVersion: $fromVersion
      toVersion: $toVersion
    ) {
      fromVersion
      toVersion
      diffContent
    }
  }
`,Z=v`
  mutation EnableSkillVersioning($input: EnableSkillVersioningInput!) {
    enableSkillVersioning(input: $input) {
      tag
      commitHash
      message
      createdAt
      isActive
    }
  }
`,ee=v`
  mutation ActivateSkillVersion($input: ActivateSkillVersionInput!) {
    activateSkillVersion(input: $input) {
      tag
      commitHash
      message
      createdAt
      isActive
    }
  }
`,le=P("skill",()=>{const o=f([]),c=f(null),S=f(null),s=f(!1),i=f("");function d(n,e){const a=o.value.findIndex(t=>t.name===n);if(a!==-1){const t=[...o.value];t[a]={...t[a],...e},o.value=t}c.value?.name===n&&(c.value={...c.value,...e})}async function h(){s.value=!0,i.value="";try{const n=m(),{data:e,errors:a}=await n.query({query:x,fetchPolicy:"network-only"});if(a&&a.length>0)throw new Error(a.map(t=>t.message).join(", "));e?.skills&&(o.value=e.skills)}catch(n){throw i.value=n.message,n}finally{s.value=!1}}async function g(n){s.value=!0,i.value="";try{const e=m(),{data:a,errors:t}=await e.query({query:R,variables:{name:n},fetchPolicy:"network-only"});if(t&&t.length>0)throw new Error(t.map(l=>l.message).join(", "));return a?.skill?(c.value=a.skill,a.skill):(c.value=null,null)}catch(e){throw i.value=e.message,e}finally{s.value=!1}}async function w(n){s.value=!0,i.value="";try{const e=m(),{data:a,errors:t}=await e.query({query:O,variables:{name:n},fetchPolicy:"network-only"});if(t&&t.length>0)throw new Error(t.map(l=>l.message).join(", "));a?.skillFileTree&&(S.value=a.skillFileTree)}catch(e){throw i.value=e.message,e}finally{s.value=!1}}async function y(n,e){i.value="";try{const a=m(),{data:t,errors:l}=await a.query({query:U,variables:{skillName:n,path:e},fetchPolicy:"network-only"});if(l&&l.length>0)throw new Error(l.map(r=>r.message).join(", "));return t?.skillFileContent??null}catch(a){throw i.value=a.message,a}}async function p(n){s.value=!0,i.value="";try{const e=m(),{data:a,errors:t}=await e.mutate({mutation:B,variables:{input:n}});if(t&&t.length>0)throw new Error(t.map(l=>l.message).join(", "));if(a?.createSkill)return o.value=[...o.value,a.createSkill],a.createSkill;throw new Error("Failed to create skill: No data returned")}catch(e){throw i.value=e.message,e}finally{s.value=!1}}async function E(n){s.value=!0,i.value="";try{const e=m(),{data:a,errors:t}=await e.mutate({mutation:H,variables:{input:n}});if(t&&t.length>0)throw new Error(t.map(l=>l.message).join(", "));if(a?.updateSkill){const l=a.updateSkill,r=o.value.findIndex(u=>u.name===l.name);if(r!==-1){const u=[...o.value];u[r]=l,o.value=u}return c.value?.name===l.name&&(c.value=l),l}throw new Error("Failed to update skill: No data returned")}catch(e){throw i.value=e.message,e}finally{s.value=!1}}async function V(n){s.value=!0,i.value="";try{const e=m(),{data:a,errors:t}=await e.mutate({mutation:M,variables:{name:n}});if(t&&t.length>0)throw new Error(t.map(l=>l.message).join(", "));if(a?.deleteSkill)return a.deleteSkill.success&&(o.value=o.value.filter(l=>l.name!==n),c.value?.name===n&&(c.value=null)),a.deleteSkill;throw new Error("Failed to delete skill: No data returned")}catch(e){throw i.value=e.message,e}finally{s.value=!1}}async function L(n,e,a){i.value="";try{const t=m(),{data:l,errors:r}=await t.mutate({mutation:z,variables:{skillName:n,path:e,content:a}});if(r&&r.length>0)throw new Error(r.map(u=>u.message).join(", "));return l?.uploadSkillFile??!1}catch(t){throw i.value=t.message,t}}async function $(n,e){i.value="";try{const a=m(),{data:t,errors:l}=await a.mutate({mutation:J,variables:{skillName:n,path:e}});if(l&&l.length>0)throw new Error(l.map(r=>r.message).join(", "));return t?.deleteSkillFile??!1}catch(a){throw i.value=a.message,a}}async function b(n){s.value=!0,i.value="";try{const e=m(),{data:a,errors:t}=await e.mutate({mutation:Q,variables:{name:n}});if(t&&t.length>0)throw new Error(t.map(l=>l.message).join(", "));if(a?.disableSkill){const l=a.disableSkill,r=o.value.findIndex(u=>u.name===l.name);if(r!==-1){const u=[...o.value];u[r]=l,o.value=u}return c.value?.name===l.name&&(c.value=l),l}throw new Error("Failed to disable skill: No data returned")}catch(e){throw i.value=e.message,e}finally{s.value=!1}}async function I(n){s.value=!0,i.value="";try{const e=m(),{data:a,errors:t}=await e.mutate({mutation:W,variables:{name:n}});if(t&&t.length>0)throw new Error(t.map(l=>l.message).join(", "));if(a?.enableSkill){const l=a.enableSkill,r=o.value.findIndex(u=>u.name===l.name);if(r!==-1){const u=[...o.value];u[r]=l,o.value=u}return c.value?.name===l.name&&(c.value=l),l}throw new Error("Failed to enable skill: No data returned")}catch(e){throw i.value=e.message,e}finally{s.value=!1}}async function F(n){i.value="";try{const e=m(),{data:a,errors:t}=await e.query({query:X,variables:{skillName:n},fetchPolicy:"network-only"});if(t&&t.length>0)throw new Error(t.map(l=>l.message).join(", "));return a?.skillVersions??[]}catch(e){throw i.value=e.message,e}}async function N(n,e,a){i.value="";try{const t=m(),{data:l,errors:r}=await t.query({query:Y,variables:{skillName:n,fromVersion:e,toVersion:a},fetchPolicy:"network-only"});if(r&&r.length>0)throw new Error(r.map(u=>u.message).join(", "));return l?.skillVersionDiff??null}catch(t){throw i.value=t.message,t}}async function _(n){s.value=!0,i.value="";try{const e=m(),{data:a,errors:t}=await e.mutate({mutation:Z,variables:{input:{skillName:n}}});if(t&&t.length>0)throw new Error(t.map(l=>l.message).join(", "));if(a?.enableSkillVersioning){const l=a.enableSkillVersioning;return d(n,{isVersioned:!0,activeVersion:l.tag}),l}throw new Error("Failed to enable skill versioning: No data returned")}catch(e){throw i.value=e.message,e}finally{s.value=!1}}async function T(n,e){s.value=!0,i.value="";try{const a=m(),{data:t,errors:l}=await a.mutate({mutation:ee,variables:{input:{skillName:n,version:e}}});if(l&&l.length>0)throw new Error(l.map(r=>r.message).join(", "));if(t?.activateSkillVersion){const r=t.activateSkillVersion;return d(n,{isVersioned:!0,activeVersion:r.tag}),r}throw new Error("Failed to activate skill version: No data returned")}catch(a){throw i.value=a.message,a}finally{s.value=!1}}function q(n){c.value=n}function A(){i.value=""}const C=k(()=>o.value),D=k(()=>c.value),j=k(()=>S.value),K=k(()=>s.value),G=k(()=>i.value);return{skills:o,currentSkill:c,currentSkillTree:S,loading:s,error:i,fetchAllSkills:h,fetchSkill:g,fetchSkillFileTree:w,readFileContent:y,createSkill:p,updateSkill:E,deleteSkill:V,uploadFile:L,deleteFile:$,disableSkill:b,enableSkill:I,fetchSkillVersions:F,fetchSkillVersionDiff:N,enableSkillVersioning:_,activateSkillVersion:T,setCurrentSkill:q,clearError:A,getSkills:C,getCurrentSkill:D,getCurrentSkillTree:j,getLoading:K,getError:G}});export{le as u};
