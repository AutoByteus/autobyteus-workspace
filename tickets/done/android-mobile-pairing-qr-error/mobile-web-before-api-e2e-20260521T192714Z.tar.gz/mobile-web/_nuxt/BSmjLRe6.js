import{D as f,r as L}from"./iaM639hE.js";import{L as c,E as x,M as u,c as v,w as G,p as R}from"#entry";const j=c`
  query GetLLMProviderApiKeyConfigured($providerId: String!) {
    getLlmProviderApiKeyConfigured(providerId: $providerId)
  }
`,E=c`
  query GetAvailableLLMProvidersWithModels($runtimeKind: String) {
    availableLlmProvidersWithModels(runtimeKind: $runtimeKind) {
      __typename
      provider {
        __typename
        id
        name
        providerType
        isCustom
        baseUrl
        apiKeyConfigured
        status
        statusMessage
      }
      models {
        __typename
        modelIdentifier
        name
        value
        canonicalName
        providerId
        providerName
        providerType
        runtime
        hostUrl
        configSchema
        maxContextTokens
        activeContextTokens
        maxInputTokens
        maxOutputTokens
      }
    }
    availableAudioProvidersWithModels(runtimeKind: $runtimeKind) {
      __typename
      provider {
        __typename
        id
        name
        providerType
        isCustom
        baseUrl
        apiKeyConfigured
        status
        statusMessage
      }
      models {
        __typename
        modelIdentifier
        name
        value
        canonicalName
        providerId
        providerName
        providerType
        runtime
        hostUrl
      }
    }
    availableImageProvidersWithModels(runtimeKind: $runtimeKind) {
      __typename
      provider {
        __typename
        id
        name
        providerType
        isCustom
        baseUrl
        apiKeyConfigured
        status
        statusMessage
      }
      models {
        __typename
        modelIdentifier
        name
        value
        canonicalName
        providerId
        providerName
        providerType
        runtime
        hostUrl
      }
    }
  }
`,N=c`
  query GetGeminiSetupConfig {
    getGeminiSetupConfig {
      mode
      geminiApiKeyConfigured
      vertexApiKeyConfigured
      vertexProject
      vertexLocation
    }
  }
`,k=c`
  mutation SetLLMProviderApiKey($providerId: String!, $apiKey: String!) {
    setLlmProviderApiKey(providerId: $providerId, apiKey: $apiKey)
  }
`,q=c`
  mutation ReloadLLMModels($runtimeKind: String) {
    reloadLlmModels(runtimeKind: $runtimeKind)
  }
`,U=c`
  mutation ReloadLLMProviderModels($providerId: String!, $runtimeKind: String) {
    reloadLlmProviderModels(providerId: $providerId, runtimeKind: $runtimeKind)
  }
`,B=c`
  mutation ProbeCustomLlmProvider($input: CustomLlmProviderInputObject!) {
    probeCustomLlmProvider(input: $input) {
      name
      providerType
      baseUrl
      discoveredModels {
        id
        name
      }
    }
  }
`,z=c`
  mutation CreateCustomLlmProvider($input: CustomLlmProviderInputObject!, $runtimeKind: String) {
    createCustomLlmProvider(input: $input, runtimeKind: $runtimeKind) {
      id
      name
      providerType
      isCustom
      baseUrl
      apiKeyConfigured
      status
      statusMessage
    }
  }
`,D=c`
  mutation DeleteCustomLlmProvider($providerId: String!, $runtimeKind: String) {
    deleteCustomLlmProvider(providerId: $providerId, runtimeKind: $runtimeKind)
  }
`,V=c`
  mutation SetGeminiSetupConfig(
    $mode: String!
    $geminiApiKey: String
    $vertexApiKey: String
    $vertexProject: String
    $vertexLocation: String
  ) {
    setGeminiSetupConfig(
      mode: $mode
      geminiApiKey: $geminiApiKey
      vertexApiKey: $vertexApiKey
      vertexProject: $vertexProject
      vertexLocation: $vertexLocation
    )
  }
`,h=e=>typeof e=="object"&&e!==null,S=e=>typeof e=="number"&&Number.isFinite(e),I=(...e)=>{for(const i of e)if(typeof i=="string"&&i.trim().length>0)return i.trim()},X=(e,i)=>{if(e==null)return!1;switch(i.type){case"boolean":if(typeof e!="boolean")return!1;break;case"string":if(typeof e!="string")return!1;break;case"integer":if(!S(e)||!Number.isInteger(e))return!1;break;case"number":if(!S(e))return!1;break}if(Array.isArray(i.enum)&&i.enum.length>0&&!i.enum.some(r=>Object.is(r,e))||S(e)&&(typeof i.minimum=="number"&&e<i.minimum||typeof i.maximum=="number"&&e>i.maximum))return!1;if(typeof e=="string"&&typeof i.pattern=="string"&&i.pattern.length>0)try{if(!new RegExp(i.pattern).test(e))return!1}catch{}return!0},T=e=>{if(!h(e))return null;if(Array.isArray(e.parameters)){const i={},r=e.parameters??[];for(const t of r)!t||typeof t.name!="string"||t.name.length===0||(i[t.name]={type:t.type,title:I(t.title,t.label,t.display_name),description:t.description,enum:t.enum_values,default:t.default_value,minimum:t.min_value??null,maximum:t.max_value??null,pattern:t.pattern??null,required:t.required});return Object.keys(i).length>0?i:null}if(h(e.properties)){const i={},r=e.properties??{},t=new Set(Array.isArray(e.required)?e.required?.filter(o=>typeof o=="string")??[]:[]);for(const[o,n]of Object.entries(r)){if(!h(n))continue;const d=typeof n.type=="string"?n.type:void 0,l=I(n.title,n.label,n.display_name),g=typeof n.description=="string"?n.description:void 0,M=Array.isArray(n.enum)?n.enum:void 0,b="default"in n?n.default:void 0,p=typeof n.minimum=="number"?n.minimum:n.minimum===null?null:void 0,P=typeof n.maximum=="number"?n.maximum:n.maximum===null?null:void 0,y=typeof n.pattern=="string"?n.pattern:void 0;i[o]={type:d,title:l,description:g,enum:M,default:b,minimum:p,maximum:P,pattern:y,required:t.has(o)}}return Object.keys(i).length>0?i:null}return null},le=(e,i)=>{if(!e||!h(i))return i&&h(i)?{...i}:null;const r={};for(const[t,o]of Object.entries(i)){const n=e[t];n&&X(o,n)&&(r[t]=o)}return Object.keys(r).length>0?r:null},C=()=>({mode:"AI_STUDIO",geminiApiKeyConfigured:!1,vertexApiKeyConfigured:!1,vertexProject:null,vertexLocation:null}),w=(e,i)=>{const r={...i};for(const t of e)r[t.provider.id]={...r[t.provider.id]??{},apiKeyConfigured:t.provider.apiKeyConfigured};return r},_=(e,i,r)=>e.map(t=>t.provider.id===i?{...t,provider:{...t.provider,apiKeyConfigured:r}}:t),Y=e=>e.mode==="VERTEX_EXPRESS"?e.vertexApiKeyConfigured:e.mode==="VERTEX_PROJECT"?!!((e.vertexProject??"").trim()&&(e.vertexLocation??"").trim()):e.geminiApiKeyConfigured,O=x("llmProviderConfig",{state:()=>({providersWithModels:[],audioProvidersWithModels:[],imageProvidersWithModels:[],providerConfigs:{},isLoadingModels:!1,isReloadingModels:!1,isReloadingProviderModels:!1,reloadingProvider:null,hasFetchedProviders:!1,modelRuntimeKind:"autobyteus",geminiSetup:C()}),getters:{providers(e){return e.providersWithModels.map(i=>i.provider.id)},models(e){return e.providersWithModels.flatMap(i=>i.models.map(r=>r.modelIdentifier))},audioModels(e){return e.audioProvidersWithModels.flatMap(i=>i.models.map(r=>r.modelIdentifier))},imageModels(e){return e.imageProvidersWithModels.flatMap(i=>i.models.map(r=>r.modelIdentifier))},providerById(e){return i=>i?e.providersWithModels.find(r=>r.provider.id===i)?.provider??null:null},providersWithModelsForSelection(e){return e.providersWithModels.filter(i=>i.models&&i.models.length>0)},modelConfigSchemaByIdentifier(e){return i=>{if(!i)return null;for(const r of e.providersWithModels){const t=r.models.find(o=>o.modelIdentifier===i);if(t?.configSchema){const o=T(t.configSchema);if(o&&Object.keys(o).length>0)return o}}return null}},canonicalModels(e){const i=new Set;e.providersWithModels.forEach(t=>{t.models.forEach(o=>{o.canonicalName&&i.add(o.canonicalName)})});const r=Array.from(i).sort();return r.unshift("default"),r}},actions:{getProviderForModel(e){if(!e||!this.providersWithModels)return null;for(const i of this.providersWithModels){const r=i.models.find(t=>t.modelIdentifier===e);if(r)return r.providerType}return null},getModelValue(e){for(const i of this.providersWithModels){const r=i.models.find(t=>t.modelIdentifier===e);if(r)return r.value}return null},getModelIdentifierByValue(e){for(const i of this.providersWithModels){const r=i.models.find(t=>t.value===e);if(r)return r.modelIdentifier}return null},async fetchProvidersWithModels(e="autobyteus"){if(this.hasFetchedProviders&&this.modelRuntimeKind===e)return this.providersWithModels;this.isLoadingModels=!0;const i=u();try{const{data:r}=await i.query({query:E,variables:{runtimeKind:e}});return this.providersWithModels=r?.availableLlmProvidersWithModels??[],this.audioProvidersWithModels=r?.availableAudioProvidersWithModels??[],this.imageProvidersWithModels=r?.availableImageProvidersWithModels??[],this.providerConfigs=w(this.providersWithModels,this.providerConfigs),this.modelRuntimeKind=e,this.hasFetchedProviders=!0,this.providersWithModels}catch(r){throw console.error("Failed to fetch providers and models:",r),this.providersWithModels=[],this.audioProvidersWithModels=[],this.imageProvidersWithModels=[],r}finally{this.isLoadingModels=!1}},async reloadProvidersWithModels(e={}){const{showLoading:i=!0}=e,r=e.runtimeKind??this.modelRuntimeKind??"autobyteus";i&&(this.isReloadingModels=!0);const t=u();try{const{data:o}=await t.query({query:E,variables:{runtimeKind:r},fetchPolicy:"network-only"});return this.providersWithModels=o?.availableLlmProvidersWithModels??[],this.audioProvidersWithModels=o?.availableAudioProvidersWithModels??[],this.imageProvidersWithModels=o?.availableImageProvidersWithModels??[],this.providerConfigs=w(this.providersWithModels,this.providerConfigs),this.modelRuntimeKind=r,this.hasFetchedProviders=!0,this.providersWithModels}catch(o){throw console.error("Failed to reload providers and models:",o),this.providersWithModels=[],this.audioProvidersWithModels=[],this.imageProvidersWithModels=[],o}finally{i&&(this.isReloadingModels=!1)}},async reloadModels(){this.isReloadingModels=!0;try{const e=u(),{data:i,errors:r}=await e.mutate({mutation:q,variables:{runtimeKind:this.modelRuntimeKind}});if(r&&r.length>0)throw new Error(r.map(o=>o.message).join(", "));const t=i?.reloadLlmModels;if(t&&t.includes("successfully"))return await this.reloadProvidersWithModels(),!0;throw new Error(t||"Failed to reload models")}catch(e){throw console.error("Failed to reload models:",e),e}finally{this.isReloadingModels=!1}},async reloadModelsForProvider(e){if(!e)throw new Error("Provider is required to reload models.");this.isReloadingProviderModels=!0,this.reloadingProvider=e;try{const i=u(),{data:r,errors:t}=await i.mutate({mutation:U,variables:{providerId:e,runtimeKind:this.modelRuntimeKind}});if(t&&t.length>0)throw new Error(t.map(n=>n.message).join(", "));const o=r?.reloadLlmProviderModels;if(o&&o.includes("successfully"))return await this.reloadProvidersWithModels({showLoading:!1}),!0;throw new Error(o||"Failed to reload provider models")}catch(i){throw console.error(`Failed to reload models for provider ${e}:`,i),i}finally{this.isReloadingProviderModels=!1,this.reloadingProvider=null}},async setLLMProviderApiKey(e,i){try{const r=u(),{data:t,errors:o}=await r.mutate({mutation:k,variables:{providerId:e,apiKey:i}});if(o&&o.length>0)throw new Error(o.map(d=>d.message).join(", "));const n=t?.setLlmProviderApiKey;if(n&&n.includes("successfully"))return this.providerConfigs[e]={apiKeyConfigured:!0},this.providersWithModels=_(this.providersWithModels,e,!0),e==="AUTOBYTEUS"&&await this.reloadModels(),!0;throw new Error(n||"Failed to set API key")}catch(r){throw console.error("Failed to set provider API key:",r),r}},async getLLMProviderApiKeyConfigured(e){const i=this.providersWithModels.find(t=>t.provider.id===e)?.provider.apiKeyConfigured;if(typeof i=="boolean")return this.providerConfigs[e]={apiKeyConfigured:i},i;const r=u();try{const{data:t}=await r.query({query:j,variables:{providerId:e}}),o=!!t?.getLlmProviderApiKeyConfigured;return this.providerConfigs[e]={apiKeyConfigured:o},o}catch(t){throw console.error(`Failed to get provider API key configured status for ${e}:`,t),t}},async probeCustomProvider(e){const i=u(),{data:r,errors:t}=await i.mutate({mutation:B,variables:{input:e}});if(t&&t.length>0)throw new Error(t.map(o=>o.message).join(", "));return r?.probeCustomLlmProvider},async createCustomProvider(e,i){const r=i??this.modelRuntimeKind,t=u(),{data:o,errors:n}=await t.mutate({mutation:z,variables:{input:e,runtimeKind:r}});if(n&&n.length>0)throw new Error(n.map(l=>l.message).join(", "));const d=o?.createCustomLlmProvider;if(!d)throw new Error("Failed to create custom provider");return await this.reloadProvidersWithModels({showLoading:!1,runtimeKind:r}),d},async deleteCustomProvider(e,i){const r=i??this.modelRuntimeKind,t=u(),{data:o,errors:n}=await t.mutate({mutation:D,variables:{providerId:e,runtimeKind:r}});if(n&&n.length>0)throw new Error(n.map(l=>l.message).join(", "));const d=o?.deleteCustomLlmProvider;if(!d||!d.includes("successfully"))throw new Error(d||"Failed to delete custom provider");return delete this.providerConfigs[e],await this.reloadProvidersWithModels({showLoading:!1,runtimeKind:r}),!0},async fetchGeminiSetupConfig(){const e=u();try{const{data:i}=await e.query({query:N,fetchPolicy:"network-only"});return this.geminiSetup=i?.getGeminiSetupConfig??C(),this.geminiSetup}catch(i){throw console.error("Failed to fetch Gemini setup config:",i),this.geminiSetup=C(),i}},async setGeminiSetupConfig(e){const i=u();try{const{data:r,errors:t}=await i.mutate({mutation:V,variables:{mode:e.mode,geminiApiKey:e.geminiApiKey??null,vertexApiKey:e.vertexApiKey??null,vertexProject:e.vertexProject??null,vertexLocation:e.vertexLocation??null}});if(t&&t.length>0)throw new Error(t.map(d=>d.message).join(", "));const o=r?.setGeminiSetupConfig;if(!o||!o.includes("successfully"))throw new Error(o||"Failed to save Gemini setup");await this.fetchGeminiSetupConfig();const n=Y(this.geminiSetup);return this.providerConfigs.GEMINI={apiKeyConfigured:n},this.providersWithModels=_(this.providersWithModels,"GEMINI",n),!0}catch(r){throw console.error("Failed to set Gemini setup config:",r),r}}}}),H=c`
  query GetRuntimeAvailabilities {
    runtimeAvailabilities {
      runtimeKind
      enabled
      reason
    }
  }
`,J=x("runtimeAvailability",{state:()=>({availabilities:[],isLoading:!1,hasFetched:!1}),getters:{availabilityByKind:e=>i=>e.availabilities.find(r=>r.runtimeKind===i)??null,isRuntimeEnabled(){return e=>{const i=this.availabilityByKind(e);return i?i.enabled:e===f}},runtimeReason(){return e=>this.availabilityByKind(e)?.reason??null}},actions:{async fetchRuntimeAvailabilities(e=!1){if(this.hasFetched&&!e)return this.availabilities;this.isLoading=!0;try{const i=u(),{data:r}=await i.query({query:H,fetchPolicy:e?"network-only":"cache-first"}),t=Array.isArray(r?.runtimeAvailabilities)?r.runtimeAvailabilities:[];return this.availabilities=t.filter(o=>o&&typeof o.runtimeKind=="string").map(o=>({runtimeKind:o.runtimeKind,enabled:o.enabled===!0,reason:typeof o.reason=="string"&&o.reason.trim().length>0?o.reason:null})),this.hasFetched=!0,this.availabilities}finally{this.isLoading=!1}}}}),Q=e=>e.providerType==="OPENAI_COMPATIBLE",Z=e=>(e?.trim()||f)===f,$=(e,i)=>{const r=e.name?.trim();return Q(e)&&r?r:Z(i)?e.modelIdentifier:r||e.modelIdentifier},ee=(e,i,r)=>{const t=$(i,r),o=e?.trim();return o?`${o} / ${t}`:t},ie=e=>e.map(i=>({provider:{...i.provider},models:i.models.map(r=>({...r,configSchema:r.configSchema&&typeof r.configSchema=="object"&&!Array.isArray(r.configSchema)?{...r.configSchema}:r.configSchema??null}))})),re=(e,i=!1)=>{const r=(e||"").trim();return r||(i?"":f)},W=e=>(e||"").trim()||f,te=async(e,i=O())=>{const r=await i.fetchProvidersWithModels(e),t=Array.isArray(r)&&r.length>0?r:i.providersWithModelsForSelection??[];return ie(t)},de=e=>{const i=O(),r=J(),t=R({}),o=R(!1);r.fetchRuntimeAvailabilities().catch(s=>{console.error("Failed to fetch runtime availabilities:",s)});const n=v(()=>e.allowBlankRuntime===!0),d=v(()=>re(e.runtimeKind.value,n.value)),l=v(()=>W(e.runtimeKind.value)),g=async s=>{const a=W(s);if(!t.value[a]){o.value=!0;try{const m=await te(a,i);t.value={...t.value,[a]:m}}finally{o.value=!1}}};G(()=>l.value,s=>{g(s)},{immediate:!0});const M=v(()=>{const s=l.value,a=new Map;for(const m of r.availabilities)a.set(m.runtimeKind,{value:m.runtimeKind,label:L(m.runtimeKind),enabled:m.enabled});return a.has(f)||a.set(f,{value:f,label:L(f),enabled:!0}),a.has(s)||a.set(s,{value:s,label:L(s),enabled:r.isRuntimeEnabled(s)}),Array.from(a.values()).filter(m=>m.enabled||s===m.value)}),b=v(()=>{const s=r.availabilityByKind(l.value);return s?s.enabled?null:r.runtimeReason(l.value):l.value===f?null:"Runtime is not available in current capabilities."}),p=v(()=>t.value[l.value]??[]),P=v(()=>p.value.length?p.value.map(s=>({label:s.provider.name,items:s.models.map(a=>({id:a.modelIdentifier,name:$(a,l.value),selectedLabel:ee(s.provider.name,a,l.value)}))})):[]),y=v(()=>p.value.flatMap(s=>s.models.map(a=>a.modelIdentifier)));return{availableProviderGroups:p,effectiveRuntimeKind:l,ensureModelsForRuntime:g,groupedModelOptions:P,hasModelIdentifier:s=>{const a=(s||"").trim();return a?y.value.includes(a):!1},isLoadingModels:o,modelConfigSchemaByIdentifier:s=>{const a=(s||"").trim();if(!a)return null;for(const m of p.value){const A=m.models.find(F=>F.modelIdentifier===a);if(!A?.configSchema)continue;const K=T(A.configSchema);if(K&&Object.keys(K).length>0)return K}return null},modelIdentifiers:y,normalizedStoredRuntimeKind:d,runtimeOptions:M,selectedRuntimeUnavailableReason:b}};export{O as a,ee as b,J as c,$ as g,te as l,re as n,W as r,le as s,de as u};
