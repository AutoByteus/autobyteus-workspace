import{L as m,E as P,y as _,c as $,p as v,N as w,M as S,w as x}from"#entry";const F=m`
  fragment ApplicationCatalogFields on Application {
    __typename
    id
    name
    description
    iconAssetPath
    entryHtmlAssetPath
    executionResourceSlots {
      slotKey
      required
    }
  }
`,H=m`
  fragment ApplicationTechnicalDetailsFields on Application {
    __typename
    localApplicationId
    packageId
    writable
    bundleResources {
      kind
      localId
      definitionId
    }
  }
`,K=m`
  fragment ApplicationDetailFields on Application {
    ...ApplicationCatalogFields
    ...ApplicationTechnicalDetailsFields
  }
  ${F}
  ${H}
`,L=m`
  query ListApplications {
    listApplications {
      ...ApplicationCatalogFields
    }
  }
  ${F}
`,N=m`
  query GetApplicationById($id: String!) {
    application(id: $id) {
      ...ApplicationDetailFields
    }
  }
  ${K}
`,b=e=>({__typename:e.__typename,id:e.id,name:e.name,description:e.description??null,iconAssetPath:e.iconAssetPath??null,entryHtmlAssetPath:e.entryHtmlAssetPath,executionResourceSlots:[...e.executionResourceSlots??[]].map(t=>({slotKey:t.slotKey,required:t.required}))}),T=e=>({...b(e),technicalDetails:{localApplicationId:e.localApplicationId,packageId:e.packageId,writable:e.writable,bundleResources:[...e.bundleResources??[]].map(t=>({kind:t.kind,localId:t.localId,definitionId:t.definitionId}))}}),W=(e,t)=>{const o=e.findIndex(y=>y.id===t.id);if(o===-1)return[...e,t];const a=[...e];return a[o]=t,a},z=P("application",()=>{const e=v([]),t=v({}),o=v(!1),a=v(null),y=v(!1);let R=!1;const A=_(),I=$(()=>i=>t.value[i]??null),k=()=>w().isEnabled,E=async()=>{if(!await A.waitForBoundBackendReady())throw new Error(A.lastReadyError||"Bound backend is not ready")},s=i=>A.bindingRevision!==i,q=async(i=!1)=>{const c=A.bindingRevision,u=w();if(await u.ensureResolved(),s(c))return[];if(!u.isEnabled)return e.value=[],t.value={},o.value=!1,a.value=null,y.value=!1,[];if(y.value&&!i)return e.value;o.value=!0,a.value=null;try{if(await E(),s(c))return[];const l=S(),{data:p,errors:n}=await l.query({query:L,fetchPolicy:i?"network-only":"cache-first"});if(s(c))return[];if(n&&n.length>0)throw new Error(n.map(r=>r.message).join(", "));const d=[...p.listApplications??[]].map(r=>b(r)).sort((r,f)=>r.name.localeCompare(f.name)||r.id.localeCompare(f.id));return e.value=d,y.value=!0,d}catch(l){if(s(c))return[];const p=l instanceof Error?l:new Error(String(l));throw a.value=p,console.error("Failed to fetch applications:",p),p}finally{s(c)||(o.value=!1)}},B=async(i,c=!1)=>{const u=i.trim();if(!u)return null;const l=A.bindingRevision,p=w();if(await p.ensureResolved(),s(l))return null;if(!p.isEnabled)return h(),null;if(!c){const n=I.value(u);if(n)return n}o.value=!0,a.value=null;try{if(await E(),s(l))return null;const n=S(),{data:d,errors:r}=await n.query({query:N,variables:{id:u},fetchPolicy:"network-only"});if(s(l))return null;if(r&&r.length>0)throw new Error(r.map(g=>g.message).join(", "));const f=d.application?T(d.application):null;return f&&(t.value={...t.value,[f.id]:f},e.value=W(e.value,b(f)).sort((g,C)=>g.name.localeCompare(C.name)||g.id.localeCompare(C.id))),f}catch(n){if(s(l))return null;const d=n instanceof Error?n:new Error(String(n));throw a.value=d,console.error(`Failed to fetch application '${u}':`,d),d}finally{s(l)||(o.value=!1)}},D=()=>{a.value=null},h=()=>{e.value=[],t.value={},o.value=!1,a.value=null,y.value=!1};return(()=>{if(R)return;const i=w();x(()=>A.bindingRevision,()=>{h()},{flush:"sync"}),x(()=>[i.status,i.isEnabled],([c,u])=>{(c!=="resolved"||!u)&&h()},{immediate:!0,flush:"sync"}),R=!0})(),{applications:e,applicationDetails:t,loading:o,error:a,hasFetched:y,getApplicationById:I,isApplicationsEnabled:k,fetchApplications:q,fetchApplicationById:B,clearError:D,invalidateApplications:h}});export{z as u};
