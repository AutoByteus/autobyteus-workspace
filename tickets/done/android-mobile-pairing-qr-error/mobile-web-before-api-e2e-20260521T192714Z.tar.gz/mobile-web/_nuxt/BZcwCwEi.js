import{b as r}from"./ba80S9TP.js";var e=4;function a(o){return r(o,e)}export{a as c};
